# Release Notes

See GitHub for [Release Notes](https://github.com/openboxes/openboxes/releases).