# Introduction

Please be patient as our documentation expert (a.k.a our lead developer) is busy making the software not suck
so he's had some trouble finding time to update these guides. If you would like to contribute to this User Guide, 
please refer to the (contributing page)[../developer-guide/contributing.md]. 

If you would prefer to submit documentation updates as Word docs or collaborate with us
using Google Docs, please share the docs or links with our Support Team [support@openboxes.com](mailto:support@openboxes.com).

If you're impatient, not good at words & stuff, and would prefer to see User Guide completed pronto, please feel free to light a fire 
under our documentation expert. The most effective way to do that would be to shame him through any of the public 
support channels (i.e. Twitter, Slack, Google Groups, highway billboards, etc). 


