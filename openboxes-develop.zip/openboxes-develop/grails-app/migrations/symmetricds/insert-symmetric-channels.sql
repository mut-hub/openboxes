insert into sym_channel (channel_id, processing_order, max_batch_size, enabled) values('metadata_channel', 1, 100000, 1);
insert into sym_channel (channel_id, processing_order, max_batch_size, enabled) values('person_channel', 1, 100000, 1);
insert into sym_channel (channel_id, processing_order, max_batch_size, enabled) values('product_channel', 1, 100000, 1);
insert into sym_channel (channel_id, processing_order, max_batch_size, enabled) values('system_channel', 1, 100000, 1);