
# System Requirements
* Internet connection (recommended)
* Processors: 2 Cores (minimum), 4-8 Cores (recommended)
* Memory: 2GB RAM (minimum), 4GB
* Local Disk Storage: 25-50GB (minimum)

# Software Requirements
* Ubuntu 18.04 LTS 
* Java 7 
* Tomcat 7
* MySQL 5.7+ 
* SMTP service (optional, but recommended)
